<?php
/*
  If you would like to edit this file, copy it to your current theme's directory and edit it there.
  Theme My Login will always look in your theme's directory first, before using this default template.
 */



?>
<div class="tml tml-profile" id="theme-my-login<?php $template->the_instance(); ?>">
    <?php get_template_part('includes/pf-edit-profile/pf-edit', 'profile'); ?>    
</div>


