    <script src="<?php echo MRT_PLUGIN_URL ?>js/appConst.js"></script>
    
    <script src="<?php echo get_template_directory_uri() ?>/custom-theme/js/jquery.min.js"></script>
    
    <script src="<?php echo get_template_directory_uri() ?>/custom-theme/app/angular.min.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/custom-theme/app/app.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/custom-theme/app/services.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/custom-theme/app/controllers.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/custom-theme/js/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/custom-theme/js/app.js"></script>
<?php wp_footer(); ?>
</body>
</html>