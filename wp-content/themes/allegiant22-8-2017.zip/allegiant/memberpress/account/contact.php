<div class="mp_wrapper">
    <div id="mepr-account-welcome-message">
        <div class="mp_wrapper">
            <form action="" method="post">
                <?php $form = mrt_display_user_contact(); ?>
                <?php echo $form['form_html']; ?>
            </form>
        </div>
    </div>
</div>
