jQuery(function($) {


    $('.author-journal-container').mouseenter(function() {
        $(this).find('.edit-journal,.delete-journal').css('visibility','visible');
    }).mouseleave(function() {
        $(this).find('.edit-journal,.delete-journal').css('visibility','hidden');
    });

    $('.edit-journal').on('click', function() {
        var postId = $(this).attr('id').replace('edit-post-', '');
        
        var titleElem = $('#post-title-'+ postId);
        var contentElem = $('#post-content-'+ postId);

        $('#edit-journal-modal').modal('show');
        
        //alert(titleElem.text());
        //alert(contentElem.text());
        
        // var switchToInput = function() {
        //     var $input = $("<input>", {
        //         val: $(this).text(),
        //         type: "text"
        //     });
        //     $input.addClass("loadNum");
        //     $(this).replaceWith($input);
        //     $input.on("blur", switchToSpan);
        //     $input.select();
        // };
        // var switchToSpan = function() {
        //     var $span = $("<span>", {
        //         text: $(this).val()
        //     });
        //     $span.addClass("loadNum");
        //     $(this).replaceWith($span);
        //     $span.on("click", switchToInput);
        // };
        // $(".loadNum").on("click", switchToInput);
    });

    $('.delete-journal').on('click', function() {
        var jornalID = $(this).attr('id').replace('delete-post-', '');
        $('#delete-journal-modal').modal({
          backdrop: 'static',
          keyboard: false
        }).one('click', '.delete-btn', function(e) {
          $.ajax({
            method: 'POST',
            url: journal_obj.ajax_url,
            dataType: 'json',
            data:{action:'delete_journal', 'journal-id' : jornalID},
            success: function(data){
                    if(data.status == 200){
                        $('<div class="alert alert-success">\n\
                            <strong>Success!</strong> Journal removed successfully.\n\
                        </div>').prependTo('#delete-journal-modal .modal-body').delay(1000).fadeOut(function(){
                            $('.journal-'+jornalID).fadeOut(500);
                            $(this).remove();
                            $('#delete-journal-modal').modal('hide');
                        });
                        //$(this).("Journal removed successfully");
                    }else{
                        $('<div class="alert alert-danger">\n\
                            <strong>Failed!</strong> Something went wrong. Please try later.\n\
                        </div>').prependTo('#delete-journal-modal .modal-body').delay(1000).fadeOut(function(){
                       $('#delete-journal-modal').modal('hide');
                       });
                    }
                }
            });
        });
        });


    $('#add-journal').on('click', function(){
        $('#edit-journal-modal').modal('show');
    });

    
});