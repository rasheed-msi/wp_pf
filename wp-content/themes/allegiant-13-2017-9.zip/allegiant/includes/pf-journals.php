<?php

/**
 * Post Type : Journals
 */

function pf_journal_scripts() {
	wp_register_script( 'pf-journal', get_template_directory_uri() . '/includes/js/pf-journal.js', array('jquery'), '1.0.0', true );
	wp_localize_script( 'pf-journal', 'journal_obj', array('ajax_url' => admin_url( 'admin-ajax.php' )) );
	wp_enqueue_script('pf-journal');
}
add_action( 'wp_enqueue_scripts', 'pf_journal_scripts' );

add_action('wp_ajax_delete_journal', 'pf_journal_del_func');
add_action('wp_ajax_nopriv_delete_journal', 'pf_journal_del_func');

function pf_journal_del_func(){
	$journal_id = isset($_POST['journal-id']) && is_numeric($_POST['journal-id']) ? $_POST['journal-id'] : 0;
	if($journal_id != 0){
		global $wpdb;
		$status = $wpdb->update( $wpdb->posts, array( 'post_status' => 'trash' ), array( 'ID' => $journal_id ) );
		if($status == 1){
			echo json_encode(array('status' => 200, 'message' => 'Deleted successfully'));		
		}else{
			echo json_encode(array('status' => 400, 'message' => 'Something went wrong. Please try later.'));
		}
	}else{
		echo json_encode(array('status' => 401, 'message' => 'Something went wrong. Please try later.'));
	}
	die();
}
