<?php

/*theme my login customisations required files*/
require_once PF_DEP_PLUGIN_PATH .'/tml/processors/pf-email-templates.php'; //for email templates